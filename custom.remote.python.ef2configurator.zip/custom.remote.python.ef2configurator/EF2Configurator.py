from ruxit.api.base_plugin import RemoteBasePlugin
from DTUtils import Logger
from ruxit.api.exceptions import ConfigException
import pickle
import os
import tempfile
import requests
import time
import urllib3
import socket

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

cacheFile = "dump.pkl"
attempts_max = 3
sleep_time = 1

configTemplate = {  
    "value": {
    "enabled": True,
    "description": "",
    "version": "",
    "featureSets": [
    "all"
      ],
      "activationContext": "REMOTE",
      "prometheusRemote": {
        "endpoints": []
      }
    },
    "scope": ""}



# LIMITATIONS
# endpoint removal must be done manually
# change of password or user won't trigger an update only the URL. Could do user but as the password is hashed out it isn't possible. 
# A DNS change will reset all the fields though.
# If a configuration is deleted manually, the cache file will remain.


class EF2Configurator(RemoteBasePlugin):
    def initialize(self, **kwargs):
        self.logger = Logger(bool(self.config['debug']), __name__, self.activation.endpoint_name.strip())  

        self.dynatrace_URL = self.config.get("dynatrace_URL").strip()
        if self.dynatrace_URL == "":
            raise ConfigException("Dynatrace URL cannot be empty")   
        if self.dynatrace_URL[-1] != "/":
            self.dynatrace_URL += "/"


        self.dynatrace_token = self.config.get("dynatrace_token")
        if self.dynatrace_token == "":
            raise ConfigException("Dynatrace token cannot be empty")                 

        self.kafka_URL = self.config.get("kafka_URL")
        if self.kafka_URL == "":
            raise ConfigException("Kafka URL cannot be empty")

        self.kafka_username = self.config.get("kafka_username")
        if self.kafka_username == "":
            raise ConfigException("Kafka username cannot be empty")
    
        self.kafka_password = self.config.get("kafka_password")
        if self.kafka_password == "":
            raise ConfigException("Kafka password cannot be empty")

        self.kafka_extension_name = self.config.get("kafka_extension_name")
        if self.kafka_extension_name == "":
            raise ConfigException("Kafka extension name cannot be empty")

        self.postgres_URL = self.config.get("postgres_URL")
        if self.postgres_URL == "":
            raise ConfigException("Postgres URL cannot be empty")

        self.postgres_username = self.config.get("postgres_username")
        if self.postgres_username == "":
            raise ConfigException("Postgres username cannot be empty")
    
        self.postgres_password = self.config.get("postgres_password")
        if self.postgres_password == "":
            raise ConfigException("Postgres password cannot be empty")

        self.postgres_extension_name = self.config.get("postgres_extension_name")
        if self.postgres_extension_name == "":
            raise ConfigException("Postgres extension name cannot be empty")   

        self.opensearch_URL = self.config.get("opensearch_URL")
        if self.opensearch_URL == "":
            raise ConfigException("Opensearch URL cannot be empty")

        self.opensearch_username = self.config.get("opensearch_username")
        if self.opensearch_username == "":
            raise ConfigException("Opensearch username cannot be empty")
    
        self.opensearch_password = self.config.get("opensearch_password")
        if self.opensearch_password == "":
            raise ConfigException("Opensearch password cannot be empty")

        self.opensearch_extension_name = self.config.get("opensearch_extension_name")
        if self.opensearch_extension_name == "":
            raise ConfigException("Opensearch extension name cannot be empty")

        self.redis_URL = self.config.get("redis_URL")
        if self.redis_URL == "":
            raise ConfigException("Redis URL cannot be empty")

        self.redis_username = self.config.get("redis_username")
        if self.redis_username == "":
            raise ConfigException("Redis username cannot be empty")
    
        self.redis_password = self.config.get("redis_password")
        if self.redis_password == "":
            raise ConfigException("Redis password cannot be empty")

        self.redis_extension_name = self.config.get("redis_extension_name")
        if self.redis_extension_name == "":
            raise ConfigException("Redis extension name cannot be empty")


        self.execution_interval = self.config.get("execution_interval")  
        self.execution_count = 1

        self.ag_group = self.config.get("ag_group")
        if self.ag_group == "":
            raise ConfigException("Please enter an active gate group")

        self.path = tempfile.gettempdir() + os.path.sep

        self.logger.info("File path: " + self.path)

 
    # load the data structure not to lose objectIDs
    def loadDictionary(self):
        myDict = {}
        try:
            if not os.path.exists(self.path):
                os.makedirs(self.path)
            confFile = self.path + str(self.get_activation_context().config_id) + cacheFile
            with open(confFile, "rb") as out_file:   
                myDict = pickle.load(out_file)
        except Exception as e:
            self.logger.error("Error loading cache file:" + str(e)) 
        return myDict

    # Persists the dictionary
    def persistDictionary(self, obj):
        confFile = self.path + str(self.get_activation_context().config_id) + cacheFile
        try:
            with open(confFile, 'wb') as f:
                pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)
        except Exception as e:
            self.logger.error("Error writing cache file:" + str(e)) 
            self.logger.exception(e)


    # returns a list of IP from a DNS name. None if the lookup fails.
    def DNSlookup(self, address):
        try:
            pos = address.rfind(":")
            if pos == -1:
                raise ConfigException("Incorrect format for endpoint URL " + address) 

            if address.find("https://") == -1:
                raise ConfigException("Incorrect format for endpoint URL " + address) 

            dnsName = address[8:pos]
            pos2 = address.find("/metric")
            if pos2 == -1:
                raise ConfigException("Incorrect format for endpoint URL " + address) 
            port = address[pos+1: pos2]

            self.logger.debug("Address:" + dnsName)

            myIPS = socket.getaddrinfo(dnsName, port=port)
            ipList = []
            for IP in myIPS:
                ipList.append(IP[4][0])

            return ipList
        except Exception as e:
            self.logger.error("Address cannot be resolved: " + address)
            self.logger.error(e)
            return None

    # take 2 IP lists and see if they match. 
    # True is they are equal
    def compareLists(self, old, new):
        self.logger.debug("old:" + str(old) + ";new:" + str(new))
        if len(old) != len(new):
            return False
        for item in old:
            foundIt = False
            for subitem in new:
                if item == subitem:
                    foundIt = True
                    break
            if foundIt is False:
                return False
        return True



    # create or update a configuration
    # returns the configuration ID
    def deployConfig(self,extension_name, username, password, URL, version, objectId):
        IPList = self.DNSlookup(URL)
        # no IP found
        if IPList is None:
            return None

        # create the json object
        configTemplate["value"]["description"] = URL
        configTemplate["value"]["version"] = version
        configTemplate["scope"] = self.ag_group
        endpointList = []
        for IP in IPList:
            endpointList.append({"url": self.replaceIP(URL, IP), "authentication": {"scheme": "basic", "username": username, "password": password, "skipVerifyHttps": True}})
        configTemplate["value"]["prometheusRemote"]["endpoints"] = endpointList
        #self.logger.debug("CONFIG:" + self.dePythonize(str(configTemplate)))            

        if objectId is not None:
            # check if there are already configs
            response = self.callDTAPI(f"{self.dynatrace_URL}api/v2/extensions/{extension_name}/monitoringConfigurations/{objectId}", None, "GET")

            # the call broke so abort
            if response is None  :
                self.logger.info("Monitoring config returned no data")
                return None
            if response == "{}" :
                self.logger.info("Object is no longer valid, removing from cache")
                self.extensions[extension_name] = [None, {}]
                return None

            oldIPList = []
            for item in response["value"]["prometheusRemote"]["endpoints"]:
                tmpData = item["url"]
                if (pos := tmpData.rfind(":")) != -1 and (tmpData.find("https://")) != -1:
                    tmpData = tmpData[8:pos]
                oldIPList.append(tmpData)
            if self.compareLists(oldIPList, IPList) is False:
                self.logger.info("Update detected for " + extension_name)
                response = self.callDTAPI(f"{self.dynatrace_URL}api/v2/extensions/{extension_name}/monitoringConfigurations/" + objectId , self.dePythonize(str(configTemplate)), "PUT")
                if response is not None: 
                    # update the cache
                    self.extensions[extension_name] = [objectId, IPList]
                    return objectId
                else:
                    self.logger.error("Update config insert failed with existing description")
                    return None
            else:
                self.logger.debug("No change detected")
            return objectId

        # no known config deployed so double check that the URL is unknown too
        else:
            response = self.callDTAPI(f"{self.dynatrace_URL}api/v2/extensions/{extension_name}/monitoringConfigurations?pageSize=100", None, "GET")
            foundIt = False
            for item in response["items"]:
                if item["value"]["description"] == URL:
                    self.logger.debug("Found old configuration without an objectId")
                    objectId = item["objectId"]
                    foundIt = True


            if foundIt is False:
                self.logger.debug("Brand new configuration")
                
                response = self.callDTAPI(f"{self.dynatrace_URL}api/v2/extensions/{extension_name}/monitoringConfigurations", "[" + self.dePythonize(str(configTemplate)) + "]", "POST")
                if response is not None:
                    self.logger.info("NEW OBJECTID:" + response[0]["objectId"])

                    # update the cache
                    self.extensions[extension_name] =  [response[0]["objectId"], IPList]
                    return response[0]["objectId"]
                else:
                    self.logger.error("New config insert failed")
                    return None
            else:
                self.logger.info("Found a matching description so updating ")
                response = self.callDTAPI(f"{self.dynatrace_URL}api/v2/extensions/{extension_name}/monitoringConfigurations/" + objectId , self.dePythonize(str(configTemplate)) , "PUT")
                if response is not None: 
                    # update the cache
                    self.extensions[extension_name] = [objectId, IPList]
                    return objectId
                else:
                    self.logger.error("Update config insert failed with existing description")
                    return None


    def replaceIP(self, old, new):
        if old is not None:
            pos = old.rfind(":")
            if pos != -1:
                return ("https://" + new + old[pos:])
            else:
                return old
        else:
            return old

    def dePythonize(self, data):
        myConfigStr = str(data).replace("'", "\"")
        myConfigStr = myConfigStr.replace("False", "false")
        myConfigStr = myConfigStr.replace("True", "true")
        return myConfigStr        


    def concatJSON(self, newData, oldData):

        attribute = list(oldData.keys())[0]
        newData[attribute] = newData[attribute] + oldData[attribute]
        return newData

    # call DT API. http 429 and paging is supported
    def callDTAPI(self, URL , postData, method):
        try:
            attempts = 1
            #if postData is not None:
                #self.logger.debug("DATA:" + str(postData))
            while attempts <= attempts_max:
                if method == "POST":
                    response = requests.post(URL, data=postData, headers={"Content-Type": "application/json; charset=utf-8", "Authorization": "Api-Token " + self.dynatrace_token}, timeout=5, verify=False)
                elif method == "PUT":
                    response = requests.put(URL, data=postData, headers={"Content-Type": "application/json; charset=utf-8", "Authorization": "Api-Token " + self.dynatrace_token}, timeout=5, verify=False)
                elif method == "GET":
                    response = requests.get(URL, headers={"Authorization": "Api-Token " + self.dynatrace_token}, timeout=5, verify=False)
                
                if response.status_code == 202 or response.status_code == 200:
                    self.logger.debug("API call successful " + URL)
                    jsonData= response.json()
                    # should only occur for a GET
                    attempts = 0
                    while attempts <= attempts_max and "nextPageKey" in jsonData:
                        nextPageKey = jsonData["nextPageKey"]
                        if (pos := URL.find("?")) != -1:
                            # trim any query string
                            URL = URL[:pos]
                        URL = URL + "?nextPageKey=" + nextPageKey
                        response = requests.get(URL, headers={"Authorization": "Api-Token " + self.dynatrace_token}, timeout=5, verify=False)
                        if response.status_code == 202 or response.status_code == 200:
                            self.logger.debug("API call successful with nextPage" + URL)

                            jsonData= self.concatJSON(response.json(), jsonData)
                        elif response.status_code == 429:
                            self.logger.info("Too many requests error from API call, sleeping")
                            attempts += 1
                            time.sleep(sleep_time)
                        else:
                            self.logger.info("API error code with nextPage: " + str(response.status_code) + ":" + response.text )
                            return None
                    
                    return jsonData
                elif response.status_code == 429:    
                    self.logger.info("Too many requests error from API call, sleeping")
                    attempts += 1
                    time.sleep(sleep_time)
                elif response.status_code == 404:
                    self.logger.info("Not found")
                    return "{}"
                else:
                    self.logger.info("API error code: " + str(response.status_code) + ":" + response.text )
                    return None
            if attempts > attempts_max:
                self.logger.info("API call not sent due to repeated 429")
            return None
        except Exception as ex:
            self.logger.exception(ex)



    def query(self, **kwargs):
        try:

            if self.execution_count % self.execution_interval == 0:

                '''
                group = self.topology_builder.create_group("Raritan", "Raritan")
                device_name = self.config.get("instance")
                self.logger.info(f"Creating device. Name: {device_name}")
                self.device = group.create_device(device_name)
                '''

                self.extensions = self.loadDictionary()
                if len(self.extensions) == 0:
                    self.logger.info("Cache file is empty")
                    # The data structure is a Dict of Extensions, the first entry is the objectID or configID (if there is one) and the second is a list of IPs (DNS lookup of the Aiven address)
                    self.extensions = {self.kafka_extension_name: [None, {}], self.postgres_extension_name: [None, {}] , self.opensearch_extension_name: [None,{}], self.redis_extension_name: [None, {}]}
                else:
                    self.logger.debug("Loaded cache file: " + str(self.extensions))

                extensionList = {}
                # load all the aiven extensions and get the version number
                output = self.callDTAPI(self.dynatrace_URL + "api/v2/extensions?name=decathlon.aiven&pageSize=100", None, "GET")
                for extension in output["extensions"]:
                    extensionList[extension["extensionName"]] = extension["version"]

                # check that the correct extension name has been entered
                for item in [self.kafka_extension_name, self.postgres_extension_name, self.opensearch_extension_name, self.redis_extension_name]:
                    if item in extensionList:
                        break
                    else:
                        self.logger.info("Incorrect extension name or extension is not deployed " + item)
                        raise ConfigException("Incorrect extension name or extension is not deployed " + item)

                self.logger.debug("KAFKA")
                myObj = self.deployConfig(self.kafka_extension_name, self.kafka_username, self.kafka_password, self.kafka_URL, extensionList[self.kafka_extension_name], self.extensions[self.kafka_extension_name][0])
                if myObj is None:
                    self.logger.error("Couldn't create Kafka")

                self.logger.debug("POSTGRES")
                myObj = self.deployConfig(self.postgres_extension_name, self.postgres_username, self.postgres_password, self.postgres_URL, extensionList[self.postgres_extension_name], self.extensions[self.postgres_extension_name][0])
                if myObj is None:
                    self.logger.error("Couldn't create Postgres")

                self.logger.debug("OPENSEARCH")
                myObj = self.deployConfig(self.opensearch_extension_name, self.opensearch_username, self.opensearch_password, self.opensearch_URL, extensionList[self.opensearch_extension_name], self.extensions[self.opensearch_extension_name][0])
                if myObj is None:
                    self.logger.error("Couldn't create Opensearch")

                self.logger.debug("REDIS")
                myObj = self.deployConfig(self.redis_extension_name, self.redis_username, self.redis_password, self.redis_URL, extensionList[self.redis_extension_name], self.extensions[self.redis_extension_name][0])
                if myObj is None:
                    self.logger.error("Couldn't create Redis")

                self.persistDictionary(self.extensions)

                self.logger.debug("Finished")
            else:
                self.logger.debug("Skipping run")

        # these are final so abort the execution
        except ConfigException as e:
            raise ConfigException(e)
        except Exception as e:
            self.logger.exception(e)