import logging


# custom class to work around the fact that OA extensions ignore logger.debug messages.

class Logger():
    def __init__(self, debug: bool, className: str, endpoint: str):
        self.debugLevel = debug
        self.logger = logging.getLogger(className)
        self.endpoint = endpoint


    def info(self,msg):
        self.logger.info(self.endpoint +  " - " + msg)

    def debug(self,msg):
        if self.debugLevel == True:
            self.logger.info(self.endpoint +  " - " + msg)

    def error(self, msg):
        self.logger.error(self.endpoint +  " - " + msg)

    def warning(self, msg):
        self.logger.warning(self.endpoint +  " - " + msg)

    def critical(self, msg):
        self.logger.critical(self.endpoint +  " - " + msg)

    def exception(self, msg):
        self.logger.exception(self.endpoint +  " - " +  msg)